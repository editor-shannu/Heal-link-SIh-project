Face-api.js models will be loaded here
